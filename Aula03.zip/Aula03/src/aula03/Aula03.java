package aula03;

public class Aula03 {

    public static void main(String[] args) {
        //Garrafa garrafa = new Garrafa();

        //System.out.println("Capacidade da Garrafa: " + garrafa.getCapacidade() + " litros");
        //garrafa.encher(3);
        
        //garrafa.setTipoMaterial("Plástico");
        //garrafa.mostrarConteudo();
        
        //garrafa.esvaziar();
        //garrafa.mostrarConteudo();
       
        GarrafaTermica termica = new GarrafaTermica(5,"Acrílico");        
        termica.encher(5);
        termica.mostrarConteudo();
    }

}
