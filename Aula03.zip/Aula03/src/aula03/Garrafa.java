/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula03;

/**
 *
 * @author sala308b
 */
public class Garrafa {

    private String tipoMaterial;
    private int conteudo;
    private int capacidade = 5;
    private boolean estaTotalmenteCheia;

    /**
     * Método construtor.
     */
    public Garrafa() {

        this.capacidade = 5;
        this.conteudo = 0;
        this.tipoMaterial = "Vidro";
    }

    /**
     * Construtor sobrecarregado
     *
     * @param capacidade
     * @param tipoMaterial
     */
    public Garrafa(int capacidade, String tipoMaterial) {
        this.capacidade = capacidade;
        this.tipoMaterial = tipoMaterial;
    }

    public void encher(int i) {
        System.out.println("Enchendo a garrafa.");

        if (i <= 0) {
            this.conteudo = 0;

        } else {

            while (!this.estaTotalmenteCheia()) {
                this.conteudo++;

                if (this.conteudo >= i) {
                    System.out.println("a garrafa agora está com " + i + " listros.");

                    System.out.println("Falta(m) "
                            + (this.capacidade - this.conteudo)
                            + " listros para encher totalmente.");
                    break;
                }
            }
        }
    }

    public void esvaziar() {
        System.out.println("Esvaziando a garrafa.");
        this.setConteudo(0);
    }

    public void mostrarConteudo() {
        System.out.println("Conteudo da garrafa");

        if (conteudo == 0) {
            System.out.println("A garrafa está vazia.");
        } else {

            System.out.printf("Agora contém %s litros \n", getConteudo());
        }
        
        if (this.estaTotalmenteCheia()) {
            System.out.println("Garrafa está totalmente cheia.");
        } else {
            System.out.println("Garrafa não está totalmente cheia.");
        }

    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getConteudo() {
        return conteudo;
    }

    public void setConteudo(int conteudo) {
        this.conteudo = conteudo;
    }

    public boolean estaTotalmenteCheia() {
        return (this.capacidade == this.conteudo);
    }

}
