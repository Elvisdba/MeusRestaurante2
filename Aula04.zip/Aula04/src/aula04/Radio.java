/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author sala308b
 */
public class Radio {
    private String estacao;
    private int volume;

    public Radio(String estacao, int volume) {
        this.estacao = estacao;
        this.volume = volume;
    }

    public String getEstacao() {
        return estacao;
    }

    public void setEstacao(String estacao) {
        this.estacao = estacao;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public String toString() {
        return "Radio{" + "estacao=" + estacao + ", volume=" + volume + '}';
    }
    
}
