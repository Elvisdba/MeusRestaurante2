/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author sala308b
 */
public class Televisor {

    private String marca;
    private String tamanhoTela;
    private int volume;
    private int canal;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTamanhoTela() {
        return tamanhoTela;
    }

    public void setTamanhoTela(String tamanhoTela) {
        this.tamanhoTela = tamanhoTela;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        if (volume >= 0 && volume <= 100) {
            this.volume = volume;
        } else if (volume < 0) {
            this.volume = 0;
        } else if (volume > 100) {
            this.volume = 100;
        }
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    @Override
    public String toString() {
        return "Marca: " + marca + "\n"
                + "Tamanho da Tela...:" + tamanhoTela + "\n"
                + "Volume...: " + volume + "\n"
                + "Canal....: " + canal;
    }

}
