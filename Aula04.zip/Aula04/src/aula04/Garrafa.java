/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author sala308b
 */
public class Garrafa {

    private String tipoMaterial;
    private float capacidade, conteudo;

    public Garrafa() {
        this.capacidade = 100.0f;
        this.conteudo = 0;
    }

    public void encher(float qtde) {

        if (qtde > 0) {
            System.out.println("Enchendo a garrafa..");
            while (conteudo < qtde) {
                System.out.print("*");
                conteudo++;
                if (conteudo >= capacidade) {
                    System.out.println("\n Garrafa foi cheia com a capacidade máxima");
                    break;
                }
            }

        } else {
            System.out.println("Deve ser informado valor maior zero.");
        }
    }

    public void esvaziar() {
        if ( conteudo > 0 ) {
          System.out.println("Esvaziando a garrafa.");
          this.conteudo = 0;
        }else {
           System.out.println("A garrafa já está vazia."); 
        }
    }

    public void mostrarConteudo() {
        System.out.println("Conteúdo da garrafa: " + 
                            conteudo + " litros. ");
    }

}
