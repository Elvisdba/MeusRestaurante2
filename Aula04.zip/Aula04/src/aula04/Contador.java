/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author sala308b
 */
public class Contador {
    private static int valor;
    
    
    public static int getValor(){
       return valor;
    }
    
    public static void setValor(int v){
        valor = v;
    }
    public static void aumentar(){
        valor++;
    }
    
    public static void diminuir(){
        valor--;
    }
}
