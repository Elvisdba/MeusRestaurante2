/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author sala308b
 */
public class Aula04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Garrafa garrafa = new Garrafa();
        garrafa.encher(100.0f);
        garrafa.mostrarConteudo();
        
        garrafa.esvaziar();
        garrafa.mostrarConteudo();
         */
        //Contador.setValor(100);

        /*
        for (int i = 1; i <= 100; i++) {
            Contador.aumentar();
            System.out.println("Valor do contador:"
                    + Contador.getValor());
        }
        
        for (int i = 1; i <= 100; i++) {
            Contador.diminuir();
            System.out.println("Valor do contador:"
                    + Contador.getValor());
        }
     */
        
        Televisor tv = new Televisor();
        tv.setMarca("PANASONIC");
        tv.setTamanhoTela("52 Polegadas.");
        tv.setCanal(10);
        tv.setVolume(50);
        
        System.out.println(" ----  Informações da TV ----");
        System.out.println(tv.toString());
        
        Radio radio = new Radio("Globo", 40);
        System.out.println(radio.toString());
    }

    
     
}
