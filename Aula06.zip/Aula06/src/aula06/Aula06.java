/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula06;

import java.util.Scanner;

/**
 *
 * @author sala308b
 */
public class Aula06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  
        Carro carro = new Carro();
        carro.setMarca("Kia");
        carro.setChassi("123456");
        carro.setModelo("Subaru 2013/2013");
        
        Roda roda = new Roda();
        roda.setAro("20");
        roda.setMaterial("Fibra de carbono");        
        carro.setRoda(roda);
        
        Pneu pneu = new Pneu();
        pneu.setDiametro("20");
        pneu.setPerfil("baixo");        
        carro.setPneu(pneu);
        
        Volante volante = new Volante();
        volante.setDiametro("10 polegadas");
        volante.setEstilo("Esportivo");
        volante.setMaterial("madeira");
        carro.setVolante(volante);
        
        Motor motor = new Motor();
        motor.setCilindros(6);
        motor.setPotencia("420 CV");
        motor.setTempo(4);
        carro.setMotor(motor);
        
        Cambio cambio = new Cambio();
        cambio.setFabricante("Frab");
        cambio.setMarchas(6);
        carro.setCambio(cambio);
  
        carro.gravar();
        
        System.out.println("-------- Informações do Carro -----------------");
        System.out.println("Marca: " + carro.ler("123456").getMarca()); 
        System.out.println("Modelo: " + carro.ler("123456").getModelo());
        System.out.println("Potencia Motor: " + carro.ler("123456").getMotor().getPotencia());
        System.out.println("Roda: " + carro.ler("123456").getRoda().getMaterial());
        System.out.println("Aro Pneu: " + carro.ler("123456").getPneu().getDiametro());
        System.out.println("Perfil pneu: " + carro.ler("123456").getPneu().getPerfil());
        System.out.println("Volante: " + carro.ler("123456").getVolante().getEstilo());
        
        
        
        Pessoa tasmyne = new Pessoa();
        tasmyne.setNome("Tasmine da Silva");
        tasmyne.setCpf("999.999.999-99");
        tasmyne.setEmail("tas@myne.com");
        PersisteObjeto.gravar(tasmyne);
        
        Pessoa wander = new Pessoa();
        wander.setNome("Wanderlei Silva do Carmo");
        wander.setCpf("123456789-00");
        wander.setEmail("wander.silva@gmail.com");
        PersisteObjeto.gravar(wander);
        
        Pessoa proucurada = (Pessoa) PersisteObjeto.ler(wander);
        System.out.println("Nome da pessoa: " + proucurada.getNome());
        System.out.println("Nome da pessoa: " + proucurada.getCpf());
        System.out.println("Nome da pessoa: " + proucurada.getEmail());
        
    }
    
}
