/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author sala308b
 */
public class PersisteObjeto {
    
    public static void gravar(Object obj){
        try{
            FileOutputStream fos = new FileOutputStream("src/" + obj +".dat");
            ObjectOutputStream stream = new ObjectOutputStream(fos);
            stream.writeObject(obj);
            System.out.println("Objeto salvo com sucesso.");
        }catch (Exception ex){
            System.out.println("Erro:" + ex.toString());
        }
        
    }
    
    public static Object ler(Object obj){
        
        try{
            FileInputStream fis = new FileInputStream("src/"+obj+".dat");
            ObjectInputStream stream = new ObjectInputStream(fis);
            return (( Object ) stream.readObject());
            
        }catch(Exception ex){
            System.out.println("Erro:" + ex.toString());
            return null;
        }
    }
}
