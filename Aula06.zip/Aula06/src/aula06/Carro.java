/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula06;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author sala308b
 */
public class Carro implements ICarro, Serializable{
    private String chassi;
    private String marca;
    private String modelo;
    private Motor motor;
    private Volante volante;
    private Pneu pneu;
    private Roda roda;
    private Cambio cambio;
    public int velocidade;
    public int marcha;

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    public Volante getVolante() {
        return volante;
    }

    public void setVolante(Volante volante) {
        this.volante = volante;
    }

    public Pneu getPneu() {
        return pneu;
    }

    public void setPneu(Pneu pneu) {
        this.pneu = pneu;
    }

    public Roda getRoda() {
        return roda;
    }

    public void setRoda(Roda roda) {
        this.roda = roda;
    }

    public Cambio getCambio() {
        return cambio;
    }

    public void setCambio(Cambio cambio) {
        this.cambio = cambio;
    }

    @Override
    public void acelerar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void trocarMarcha(int marcha) {
        
    }

    @Override
    public void freiar() {
        
    }

    @Override
    public void ligar() {
        
    }

    @Override
    public void desligar() {
        
    }

    @Override
    public void gravar() {
      try {

            FileOutputStream fos = new FileOutputStream("src/carro" + this.getChassi());
            ObjectOutputStream stream = new ObjectOutputStream(fos);
            stream.writeObject(this);

            System.out.println("Informações gravada com sucesso.");
        } catch (Exception ex) {
            System.out.println("Erro ao tentar gravar dados\n" + ex.toString());
        }        
    }

    @Override
    public Carro ler(String chassi) {
      try{
            FileInputStream fis = new FileInputStream("src/carro" + chassi);
            ObjectInputStream stream = new ObjectInputStream(fis);
            return ( (Carro) stream.readObject() );
        } catch (Exception ex){
            System.out.println("Erro ao tentar ler dados\n" + ex.toString());
            return null;
        }   
    }
    
    
}
