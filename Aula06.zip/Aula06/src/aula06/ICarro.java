/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula06;

/**
 *
 * @author sala308b
 */
public interface ICarro {
    
    public void acelerar();
    public void trocarMarcha(int marcha);
    public void freiar();
    public void ligar();
    public void desligar();
    public void gravar();
    public Carro ler(String chassi);
}
