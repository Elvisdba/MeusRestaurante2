package aula03;

public class Aula03 {

    public static void main(String[] args) {
        //Garrafa garrafa = new Garrafa();

        //System.out.println("Capacidade da Garrafa: " + garrafa.getCapacidade() + " litros");
        //garrafa.encher(3);
        
        //garrafa.setTipoMaterial("Plástico");
        //garrafa.mostrarConteudo();
        
        //garrafa.esvaziar();
        //garrafa.mostrarConteudo();
       
        GarrafaTermica termica = new GarrafaTermica();        
        termica.encher(1);
        termica.mostrarConteudo();
    }

}
