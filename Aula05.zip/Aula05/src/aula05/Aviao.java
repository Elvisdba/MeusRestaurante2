/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05;

/**
 *
 * @author sala308b
 */
public class Aviao extends Veiculo {

    @Override
    public void acelerar() {
        this.velocidade += 10; 
    }

    @Override
    public void mostrarStatus() {
         if (this.status){
             System.out.println("Avião ligado");
         } else{
             System.out.println("Avião desligado");
         }       
    }
    
}
