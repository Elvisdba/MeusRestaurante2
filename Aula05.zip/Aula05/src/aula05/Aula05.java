/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05;

import aula05b.Funcionario;
import aula05b.PessoaJuridica;
import aula05c.Cliente;
import aula05c.Fornecedor;
import aula05c.Produto;
import aula05d.ProdutoPersiste;

/**
 *
 * @author sala308b
 */
public class Aula05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Veiculo veiculo = new Veiculo();
        System.out.println("Ligando o carro...");
        
        veiculo.ligar();
        veiculo.mostrarStatus();
        
        System.out.println("Acelerando....");
        veiculo.acelerar();
        
        System.out.println("Desligando o carro...");
        veiculo.desligar();
        veiculo.mostrarStatus();
        
        Aviao aviao = new Aviao();
        aviao.ligar();
        aviao.acelerar();
        aviao.mostrarStatus();
        aviao.desligar();
        aviao.mostrarStatus();
        
        Funcionario funcionario = new Funcionario();
        funcionario.setNome("Wanderlei");
        funcionario.setRg("1234567-SSP/ES");
        funcionario.setCartao("1234567890");
      
        String retorno = funcionario.toString();
        
        //System.out.println(funcionario.toString());
        System.out.println(retorno);
        
        PessoaJuridica pj = new PessoaJuridica();
        pj.setNome("Empresas Lucrativas S/A");
        pj.setCnpj("89.889.890/0001-50");
        
        
        System.out.println("Nome: " + pj.getNome());
        System.out.println("CNPJ: " + pj.getCnpj());
        
        Cliente cliente = new Cliente();
        cliente.localizar();
        
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.localizar();

        
        Produto produto = new Produto();
        produto.baixar();
        
        */
        
        ProdutoPersiste produtoPersiste = new ProdutoPersiste();
        
        produtoPersiste.setCodigo(100);
        produtoPersiste.setDescricao("Caneca para programadores Java");
        produtoPersiste.gravar();
        
        produtoPersiste.setCodigo(200);
        produtoPersiste.setDescricao("Revista Geek");
        produtoPersiste.gravar();
        
        produtoPersiste.setCodigo(300);
        produtoPersiste.setDescricao("Mouse Optico");
        produtoPersiste.gravar();
        
        produtoPersiste.setCodigo(400);
        produtoPersiste.setDescricao("Teclado Master");
        produtoPersiste.gravar();
        
        //aula05d.Produto produto =  produtoPersiste.ler(300);
        
        System.out.println("Produto pesquisado");
        System.out.println("Código: " + produtoPersiste.ler(200).getCodigo());
        System.out.println("Descrição: " + produtoPersiste.ler(200).getDescricao());
        
        
        
        
        
        
    }
    
}
