/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05;

/**
 *
 * @author sala308b
 */
public class Veiculo {

    protected int velocidade;
    protected boolean status;

    public void ligar() {
        if (!this.status) {
            this.status = true;
        }
    }

    public void desligar() {
        if ( this.status){
            this.status = false;
        }  
    }

    public void mostrarStatus() {
           if ( this.status){
               System.out.println("Carro ligado.");
           } else {
               System.out.println("Carro desligado.");
           }
    }

    public void acelerar() {
         this.velocidade++;
    }
}
