/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05d;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author sala308b
 */
public class ProdutoPersiste extends Produto {
    public String gravar(){
        
        String ret = "Produto gravado com sucesso.";
        
        try {
            FileOutputStream fos  = new FileOutputStream("src/Produto" + this.getCodigo());
            ObjectOutputStream stream = new ObjectOutputStream(fos);
            stream.writeObject(this);

        } catch (Exception ex) {
            ret = "Falha na gravação:\n" + ex.toString();
        }
        
        return ret;
    }
    public Produto ler(int codigo){
        
        try{
            FileInputStream fis = new FileInputStream("src/Produto"+codigo);
            ObjectInputStream stream = new ObjectInputStream(fis);
            return ( (Produto) stream.readObject() );
        }catch (Exception ex){
            System.out.println("Erro na leitura\n" + ex.toString());
        }
        return null;
    }
}
