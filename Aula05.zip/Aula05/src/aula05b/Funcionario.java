/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05b;

/**
 *
 * @author sala308b
 */
public class Funcionario extends PessoaFisica {

    private String cartao;

    public String getCartao() {
        return cartao;
    }

    public void setCartao(String cartao) {
        this.cartao = cartao;
    }

    @Override
    public String toString() {
        String informacao;
        informacao = "\nNome: " + this.getNome();
        informacao += "\nRG: " + this.getRg();
        informacao += "\nCartão: " + this.getCartao();

        return informacao;
    }
}
