/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula01;

//Classe  pincel...
class Pincel{
    //atributos
    int codigo; //tipo de dados inteiro (numérico)
    String cor; //tipo de dados cadeia de caracteres
    String fabricante; //tipo de dados cadeia de caracteres
    
    /**
     * Ação ou comportamento do objeto.
     */
    void escrever(){
        System.out.println("Pincel escrevendo..");
    }
    /**
     * Ação o método sobrecarregadode escrever
     * @param frase 
     */
    void escrever(String frase){
        System.out.println(frase);
    }
}

class Borracha {
    int codigo;
    String cor;
    String tamanho;
    String fabricante;
    
    /**
     * Ação ou método do objeto
     */
    void apagar(){
        System.out.println("Borracha apagando...");
    }
}

class Pessoa {
    int idade;
    String nome;
    String sexo;
    
    /**
     * Ação ou método do objeto
     * @param frase 
     */
    void falar(String frase){
        System.out.println(frase);
    }
    
    void calcularAnoNascimento(){
        System.out.printf("Eu nasci no ano de %s\n " ,
                                            2016 - idade);
    }
}


class Animal {
    String especie, sexo;
    void emitirSom(String s){
        System.out.println(s);
    }        
    
}


/**
 * Esta classe herda caracteristicas da classe animal
 * ou seja a classe ancestral ou classe pai é a classe Animal
 * @author Wanderlei Silva do Carmo
 */
class Felino extends Animal {
    
}

class Ave extends Animal {
    void voar(){
       System.out.println("Sou uma ave, estou voando...");
    }
    void voar(String s){
       System.out.println(s);
    }         
}

class MamiferoVoador extends Ave {
    boolean eVampiro(boolean b ){
       return b;    
    } 
}

/**
 *
 * @author sala308b
 */
public class Aula01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Felino leao = new Felino();
        leao.emitirSom("Leão rugindo...");
        Felino gato = new Felino();
        gato.emitirSom("Gato miando...");
        
        Ave passaro = new Ave();
           passaro.emitirSom("...Bem-te-vi");
           passaro.voar();
        
           Animal cachorro = new Animal();
           cachorro.sexo = "Masculino";
           cachorro.emitirSom("Sou um cachorro e estou latindo");
           
           Animal tigre = new Felino();
           Ave galinha = new Ave();
           
           MamiferoVoador morcego = new MamiferoVoador();
           morcego.voar("Não sou ave mas também voo");
           
           System.out.printf("Sou um morcego vampiro: %s\n ",
                              morcego.eVampiro(false));
        /*
        Pincel pincel = new Pincel(); //Instanciando a class pincel
        pincel.codigo = 101010;
        pincel.cor = "Azul";
        pincel.fabricante = "Pilot";
        pincel.escrever();
        pincel.escrever("Estou escrevendo o que me pediu...");
        
        Borracha borracha = new Borracha();
        borracha.codigo = 102030;
        borracha.cor = "Branca";
        borracha.fabricante = "Mercurio";
        borracha.tamanho = "Pequena";
        
        Pessoa p1 = new Pessoa();
        p1.idade =  20;
        p1.nome = "Maria";
        p1.sexo = "Feminino";

        Pessoa p2 = new Pessoa();
        p2.idade = 51;
        p2.nome = "Wanderlei";
        p2.sexo = "Masculino";
        
        
        System.out.println("Dados do pincel");
        System.out.println("===============");
        System.out.printf("Código: %s\n", pincel.codigo);
        System.out.printf("Cor: %s\n", pincel.cor);
        System.out.printf("Fabricante: %s\n", pincel.fabricante);
        
        System.out.println("Dados da borracha");
        System.out.println("===============");
        System.out.printf("Código: %s\n", borracha.codigo);
        System.out.printf("Cor: %s\n", borracha.cor);
        System.out.printf("Tamanho: %s\n", borracha.tamanho);
        System.out.printf("Fabricante: %s\n", borracha.fabricante);
        
        System.out.println("Dados da primeira pessoa");
        System.out.println("========================");      
        System.out.printf("Nome: %s\n", p1.nome);
        System.out.printf("Idade: %s\n", p1.idade);
        System.out.printf("Sexo: %s\n", p1.sexo);
        p1.calcularAnoNascimento();

        p1.falar("Eu sou a pessoa p1");
        
        System.out.println("Dados da segunda pessoa");
        System.out.println("========================");      
        System.out.printf("Nome: %s\n", p2.nome);
        System.out.printf("Idade: %s\n", p2.idade);
        System.out.printf("Sexo: %s\n", p2.sexo);        
        p2.falar("Eu sou a pessoa p2 e meu nome é " + p2.nome);
        p2.calcularAnoNascimento();
        */
        
        
    }
    
}
