/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package janela;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author sala308b
 */
public class Janela extends JFrame {

    private JLabel lbNome, lbEmail;
    private JTextField tfNome, tfEmail;
    private JButton btOk, btCancelar;
    private JList ltLista;
    private DefaultListModel dlm;

    public Janela() {
        inicializarComponentes();
        defineEventos();
    }

    public void inicializarComponentes() {

        lbNome = new JLabel("Nome:");
        lbEmail = new JLabel("E-mail:");
        tfNome = new JTextField(50);
        tfEmail = new JTextField(50);
        btOk = new JButton("Ok");
        btCancelar = new JButton("Cancelar");

        ltLista = new JList();
        dlm = new DefaultListModel();
        ltLista.setModel(dlm);

        lbNome.setBounds(100, 50, 50, 20);
        tfNome.setBounds(150, 50, 120, 20);
        lbEmail.setBounds(100, 75, 50, 20);
        tfEmail.setBounds(150, 75, 150, 20);
        btOk.setBounds(150, 120, 90, 30);
        btCancelar.setBounds(240, 120, 90, 30);

        ltLista.setBounds(150, 180, 290, 80);

        setSize(500, 380);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Janela Principal");

        add(lbNome);
        add(tfNome);
        add(lbEmail);
        add(tfEmail);
        add(btOk);
        add(btCancelar);

        JScrollPane brLista = new JScrollPane(ltLista);
        brLista.setBounds(ltLista.getBounds());

        dlm.addElement("Laura Silva " + "-" + "laura@email.com");
        dlm.addElement("Wanderlei Silva " + "-" + "wsilva@email.com");
        dlm.addElement("Adriana Dias " + "-" + "drika@email.com");
        dlm.addElement("André Dias " + "-" + "adias@email.com");

        add(brLista);

    }

    public void defineEventos() {
        btOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null,"Botão ok pressionado.");

                if (tfNome.getText().equals("")
                        || tfEmail.getText().equals("")) {

                    JOptionPane.showMessageDialog(null,
                            "Deve informar nome e email.",
                            "Aviso",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    dlm.addElement(tfNome.getText()
                            + " - " + tfEmail.getText());
                    tfNome.setText("");
                    tfEmail.setText("");

                    JOptionPane.showMessageDialog(null,
                            "Salvo na lista com sucesso.",
                            "Aviso",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }

            }
        });

        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                
                JOptionPane.showMessageDialog(null,
                        "Item removido com sucesso.",
                        "Aviso",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        });

        ltLista.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {

                String item = dlm.getElementAt(
                        ltLista.getSelectedIndex()).toString();

                tfNome.setText(item.split("-")[0]);
                tfEmail.setText(item.split("-")[1]);

            }
        });
    }
}
