/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import com.mysql.jdbc.MySQLConnection;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sala308b
 */
public class Conexao {

    private MySQLConnection con;

    public MySQLConnection getCon() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            File f = new File("config/config.dat");
            FileReader reader  = new FileReader(f);
            BufferedReader br = new BufferedReader(reader);
            
            StringBuilder sb = new StringBuilder();
            while ( br.ready()){
                sb.append(br.readLine());
            }
            
            //String url = "jdbc:mysql://localhost/restaurante";
            String url = sb.toString();
            
            con = (MySQLConnection) DriverManager.getConnection(url, "root", "12qwaszx");
            
            reader.close();
            br.close();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
        }

            return con;
            
    }

    public void Fechar() {
        try {
            if ( this.con != null) {
                this.con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
