/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cliente;
import model.Perfil;
import model.Usuario;

/**
 *
 * @author sala308b
 */
public class UsuarioDAO implements IDao {
    
    Conexao conexao = null;
    
    @Override
    public boolean incluir(Object o) {
        boolean retorno = false;
        try {
            conexao = new Conexao(); //cria uma nova instancia de conexao.
            StringBuilder sb = new StringBuilder();
            
            sb.append("insert into usuarios (nome,login,senha,perfil,ativo");
            sb.append("values(?,?,?,?,? ) ");
            
            String sql = sb.toString();
            
            PreparedStatement stmt = conexao.getCon().prepareStatement(sql);
            Usuario usu = (Usuario) o;

            //Pegando as propriedades do objeto.
            //E atribuindo aos parametros.
            stmt.setString(0, usu.getNome());
            stmt.setString(1, usu.getLogin());
            stmt.setString(2, usu.getSenha());
            stmt.setString(3, usu.getPerfil().getNome());
            stmt.setBoolean(4, usu.isAtivo());
            
            retorno = stmt.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        } finally {
            conexao.Fechar();
        }
        return retorno;        
    }
    
    @Override
    public boolean excluir(Object o) {
        boolean retorno = false;
        
        try {
            conexao = new Conexao();
            String sql = "delete from usuarios where codigo = ? ";
            PreparedStatement stmt = conexao.getCon().prepareStatement(sql);
            Usuario usu = (Usuario) o;
            
            stmt.setInt(0, usu.getCodigo());
            
            retorno = stmt.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        } finally {
            conexao.Fechar();
        }
        
        return retorno;        
    }
    
    @Override
    public boolean update(Object o) {
        boolean retorno = false;
        
        try {
            
            StringBuilder sb = new StringBuilder();
            sb.append("update usuarios ");
            sb.append("set nome =  ?, login = ?, senha = ?, perfil = ?, ativo = ? ");
            sb.append(" where codigo = ? ");
            
            Usuario usu = (Usuario) o;
            
            String sql = sb.toString();
            
            PreparedStatement stmt = conexao.getCon().prepareStatement(sql);
            //Pegando as propriedades do objeto.
            //E atribuindo aos parametros.
            stmt.setString(0, usu.getNome());
            stmt.setString(1, usu.getLogin());
            stmt.setString(2, usu.getSenha());
            stmt.setString(3, usu.getPerfil().getNome());
            stmt.setBoolean(4, usu.isAtivo());
            stmt.setInt(5, usu.getCodigo());
            
            retorno = stmt.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        } finally {
            conexao.Fechar();
        }
        
        return retorno;
    }
    
    @Override
    public ArrayList<Object> listar() {
        List<Object> lista = new ArrayList<>();
        
        try {
            
            conexao = new Conexao();
            
            String sql = "select * from usuarios ";
            Statement stmt = conexao.getCon().createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            Usuario usuario = null;
            Perfil perfil = new Perfil();
            
            while (rs.next()) {
                usuario = new Usuario();
                perfil = new Perfil();
                
                perfil.setNome(rs.getString("perfil"));
                usuario.setCodigo(rs.getInt("codigo"));
                usuario.setNome(rs.getString("nome"));
                usuario.setLogin(rs.getString("login"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setPerfil(perfil);
                usuario.setAtivo(rs.getBoolean("ativo"));
                
                lista.add((Object) usuario);
                
            }
            return (ArrayList<Object>) lista;
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            
            conexao.Fechar();
        }
        
        return (ArrayList<Object>) lista;
    }
    
    @Override
    public Object exibir(Object o) {
        Object usuario = null;
        
        try {
            conexao = new Conexao();
            
            String sql = "select * from usuario where codigo = ? ";
            PreparedStatement stmt = conexao.getCon().prepareStatement(sql);
            Usuario usu = (Usuario) o;
            
            stmt.setInt(0, usu.getCodigo());
            
            usuario = (Object) stmt.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            conexao.Fechar();
        }
         
        return usuario;        
    }
    
}
